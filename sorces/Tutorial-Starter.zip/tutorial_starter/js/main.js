/*  Autumn Greeting Card -- js */

(function($){
	'use strict';

	// declare actors here

	// clear stage 

	// enter floor vegetation

	// enter tree

	// enter the greeting text
	
	// the GO function ...to kick things all off
	

})(jQuery);


